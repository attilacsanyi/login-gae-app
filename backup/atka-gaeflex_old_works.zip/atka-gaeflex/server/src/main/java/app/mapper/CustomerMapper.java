package app.mapper;

import app.domain.CustomerEntity;
import app.dto.Customer;

public interface CustomerMapper {

    CustomerEntity mapToCustomerEntity(Customer customer);

    Customer mapToCustomer(CustomerEntity customerEntity);
    
}
