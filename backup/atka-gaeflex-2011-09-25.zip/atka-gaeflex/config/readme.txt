+------------------------------------------------+
|        SPRING GAE FLEX WEBAPPLICATION          |
+------------------------------------------------+

Features:

- User with roles and customers entities
- Spring security with user service
- Flex internationalization with Babel fx
- Swiz Framework 1.2
- Google appengine with High Replicant datastore

Remarks:

1. Appengin java SDK is external (not plugin)
1. Copy the hacked blazeds jar into appengine sdk lib/user directory in order to copy the ant process also into WEB-INF/lib

Build/upload process:

1. mvn clean install (build modules)
2. build.xml -> copyjars target (copy appengine jar-s into lib)
3. Refresh the server directory
4. Upload atka-gaeflex to appengine
