+------------------------------------------------+
|        FLEX-CLIENT                             |
+------------------------------------------------+

+----------------+
| Localisation:  |
+----------------+

	Flex localistion:
		Source: http://kun-janos.ro/blog/?p=179
	
		From sdk directory, example: c:\Program Files\Adobe\Adobe Flash Builder 4.5\sdks\4.5.0\bin\
		copylocale en_US hu_HU

	Maven localisation with Flex mojos
		Source: https://docs.sonatype.org/display/FLEXMOJOS/Application+Localization

+----------------+
| Components:    |
+----------------+
	MoveThis
		Source: http://www.taterboy.com/blog/2011/02/movethis-another-as3-tweening-animation-engine/