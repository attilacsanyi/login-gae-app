package app.services.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import app.repositories.RoleRepository;
import app.services.interfaces.ILoginService;
import app.services.interfaces.ISecurityService;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Service("securityService")
@RemotingDestination(channels = { "my-amf" })
public class SecurityServiceImpl implements ISecurityService
{

	@Autowired
	ILoginService			loginService;

	@Autowired
	private PasswordEncoder	passwordEncoder;

	@Autowired
	private RoleRepository	roleRepository;

	/*
	 * (non-Javadoc)
	 * @see app.services.interfaces.ISecurityService#chechPassword(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public Boolean checkPassword(String rawPassword, String encodedPassword)
	{
		return passwordEncoder.matches(rawPassword, encodedPassword);
	}

	/*
	 * (non-Javadoc)
	 * @see app.services.interfaces.ISecurityService#encodePassword(java.lang.String)
	 */
	@Override
	public String encodePassword(String rawPassword)
	{
		return passwordEncoder.encode(rawPassword);
	}

	@RemotingInclude
	public Map<String, Object> getAuthentication()
	{
		// Create demo login if no login exist and put into result
		if (loginService.getAllLogins().isEmpty())
		{
			loginService.createDemoLogin();
		}

		return getAuthenticationResult();
	}

	/**
	 * @return
	 */
	private Map<String, Object> getAuthenticationResult()
	{
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null)
		{
			return null;
		}
		Map<String, Object> authenticationResult = new HashMap<String, Object>();
		authenticationResult.put("name", authentication.getName());
		String[] authorities = new String[authentication.getAuthorities().size()];
		int i = 0;
		for (GrantedAuthority granted : authentication.getAuthorities())
		{
			System.out.println("authority: " + granted.getAuthority());
			// Authority is only a role key stored in getAuthorities() in LoginEntity
			authorities[i++] = getRoleNameByKey(KeyFactory.stringToKey(granted.getAuthority()));
		}
		authenticationResult.put("authorities", authorities);
		return authenticationResult;
	}

	/**
	 * @param roleKey
	 * @return
	 */
	private String getRoleNameByKey(Key roleKey)
	{
		return (roleRepository.get(roleKey)).getName();
	}
}
