package app.services.interfaces;

import java.util.Map;

/**
 * Business interface of the login services.
 * 
 * Get authentication Encode/decode passwords
 * 
 * @author atka
 * @date 07.29.2011
 */
public interface ISecurityService
{

	/** Check password match */
	Boolean checkPassword(String rawPassword, String encodedPassword);

	/** Encode password */
	String encodePassword(String rawPassword);

	Map<String, Object> getAuthentication();

}
