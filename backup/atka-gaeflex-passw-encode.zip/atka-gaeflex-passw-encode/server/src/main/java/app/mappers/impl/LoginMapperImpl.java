package app.mappers.impl;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.domains.LoginEntity;
import app.domains.RoleEntity;
import app.dto.Login;
import app.dto.Role;
import app.mappers.interfaces.ILoginMapper;
import app.mappers.interfaces.IRoleMapper;
import app.repositories.RoleRepository;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Component("loginMapper")
public class LoginMapperImpl implements ILoginMapper
{

	@Autowired
	private IRoleMapper		roleMapper;

	@Autowired
	private RoleRepository	roleRepository;

	public Login mapToLogin(LoginEntity loginEntity)
	{
		if (loginEntity == null)
		{
			return null;
		}
		Login login = new Login();
		login.setKey(KeyFactory.keyToString(loginEntity.getKey()));
		login.setUsername(loginEntity.getUsername());
		login.setPassword(loginEntity.getPassword());
		login.setStatus(loginEntity.getStatus());

		Collection<Role> loginRoles = new ArrayList<Role>();
		Collection<Key> loginEntityRoleKeys = loginEntity.getRoleKeys();
		if (loginEntityRoleKeys != null && !loginEntityRoleKeys.isEmpty())
		{
			for (Key roleKey : loginEntityRoleKeys)
			{
				Role role = roleMapper.mapToRole(roleRepository.get(roleKey));
				if (role != null)
				{
					loginRoles.add(role);
				}
			}
		}
		login.setRoles(loginRoles);
		return login;
	}

	public LoginEntity mapToLoginEntity(Login login)
	{
		if (login == null)
		{
			return null;
		}
		LoginEntity loginEntity = new LoginEntity();
		if (login.getKey() != null)
		{
			loginEntity.setKey(KeyFactory.stringToKey(login.getKey()));
		}
		loginEntity.setUsername(login.getUsername());
		loginEntity.setPassword(login.getPassword());
		loginEntity.setStatus(login.getStatus());

		Collection<Key> loginEntityRoleKeys = new ArrayList<Key>();
		Collection<Role> loginRoleKeys = login.getRoles();
		if (loginRoleKeys != null && !loginRoleKeys.isEmpty())
		{
			for (Role role : loginRoleKeys)
			{
				RoleEntity roleEntity = roleRepository.findRoleByName(role.getName());
				if (roleEntity != null && roleEntity.getKey() != null)
				{
					loginEntityRoleKeys.add(roleEntity.getKey());
				}
			}
		}
		loginEntity.setRoleKeys(loginEntityRoleKeys);
		return loginEntity;
	}

}
